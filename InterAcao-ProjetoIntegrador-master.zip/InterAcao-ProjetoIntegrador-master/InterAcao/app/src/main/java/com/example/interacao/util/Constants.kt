package com.example.interacao.util

class Constants {

    companion object{

        const val BASE_URL = "https://todo-mobile2.herokuapp.com/"

    }
}