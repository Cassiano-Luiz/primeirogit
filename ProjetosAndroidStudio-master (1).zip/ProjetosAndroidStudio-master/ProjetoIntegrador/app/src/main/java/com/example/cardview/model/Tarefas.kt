package com.example.cardview.model

import java.text.NumberFormat

class Tarefas (val nome: String,
               val data: String,
               val hora: String,
               val status: String
               ) {
}