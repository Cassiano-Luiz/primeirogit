package com.gui.affirmations.model

data class Affirmation(val stringResourceId: Int) {


}